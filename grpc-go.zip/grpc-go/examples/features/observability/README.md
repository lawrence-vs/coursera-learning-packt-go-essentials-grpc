This example is the Hello World example instrumented for logs, metrics, and tracing.

Please refer to Microservices Observability user guide for setup.
